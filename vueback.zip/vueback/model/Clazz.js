class Clazz{
  constructor(id,name,credit){
    this.id = id;
    this.name = name;
  }
}

module.exports = Clazz;