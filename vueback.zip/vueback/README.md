# sc-backstage
基于node+express+mysql的学生选课系统的入门项目后台

# 使用

##下载

$git clone https://github.com/pluslicy/sc-backstage.git

##安装依赖

$cd sc-backstage

$npm install

##安装数据库

数据库文件在根目录中，导入到新建数据库中，并且修改db/pool.js中的配置

##启动项目

$npm run start
