class Course{
  constructor(id,name,credit){
    this.id = id;
    this.name = name;
    this.credit = credit;
  }
}

module.exports = Course;